"Metallica - A sample project to explore FSD Tech Stack"  
